package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.dto.BillDetailsDTO;
import com.cg.dto.ConsumersDTO;
import com.cg.exception.BillException;
import com.cg.utility.DbUtil;

public class EBillDAOImpl implements IEBillDAO
{
	public int insertBillDetails(BillDetailsDTO bDTO) throws BillException
	   {
		   int billId=0,status=0;
		   try
		   {
			   Connection conn=DbUtil.createConnection();
			   PreparedStatement pst=null;
			   
			   String sql="INSERT INTO billdetails values (seq_bill_num.nextval,?,?,?,?,sysdate)";
			   pst=conn.prepareStatement(sql);
			   pst.setInt(1, Integer.parseInt(bDTO.getConsumerNum()));
			   pst.setDouble(2,bDTO.getCurrReading());
			   pst.setDouble(3,bDTO.getUnitConsumed());
			   pst.setDouble(4,bDTO.getNetAmount());
			   LocalDate dt=LocalDate.now();
			   bDTO.setBillDate(dt);
			   
			   status=pst.executeUpdate();
			   
				   if(status==1)
				   {
					 Statement s=conn.createStatement() ;
					 ResultSet rs=s.executeQuery("select seq_bill_num.currval from dual");
					 if(rs.next())
						 billId=rs.getInt(1);
				   }
			   
		   }
		   catch(SQLException se)
		   {
			  if(se.getErrorCode()==2291)      //2291 means parentkey not found exception in sql
				  throw new BillException("Error Occurred:\nNo customer details fo customer number: "+bDTO.getConsumerNum());
			  else
		          throw new BillException(se.getMessage());
		   }
		   
		   return billId;
	   }
	public ConsumersDTO selectConsumerDetails (String cnumber) throws BillException
	{
		ConsumersDTO consumer=new ConsumersDTO();
		Connection conn=DbUtil.createConnection();
		
		String sql="select * from consumers where consumer_num=?";
		try
		{
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,cnumber);
			ResultSet rs=pst.executeQuery();
			 if(rs.next())
			 {
				 consumer.setConsumerNum(rs.getString(1));
				 consumer.setConsumerName(rs.getString(2));
				 consumer.setAddress(rs.getString(3));
			 }		 
		}
		catch(SQLException se)
		   {
			if(se.getErrorCode()==2291)      //2291 means parentkey not found exception in sql
				  throw new BillException("Error Occurred:\nNo customer details fo customer number: "+cnumber);
			  else
				  throw new BillException(se.getMessage());
		   }
		   
		   return consumer;
	}
	public ArrayList<BillDetailsDTO> selectBillDetails(String cnumber) throws BillException
	{
		ArrayList<BillDetailsDTO> billD=new ArrayList<BillDetailsDTO>();
		BillDetailsDTO bDTO;//=new BillDetailsDTO();
        Connection conn=DbUtil.createConnection();
		
		String sql="select * from billdetails where consumer_num=?";
		try
		{
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,cnumber);
			ResultSet rs=pst.executeQuery();
			 while(rs.next())
			 {
			   
				 bDTO=new BillDetailsDTO();
				 bDTO.setBillNum(rs.getInt(1));
			    bDTO.setConsumerNum(rs.getString(2));
			    bDTO.setCurrReading(rs.getDouble(3));
			    bDTO.setUnitConsumed(rs.getDouble(4));
			    bDTO.setNetAmount(rs.getDouble(5));
			    bDTO.setBillDate((rs.getDate(6)).toLocalDate());
			    billD.add(bDTO);
			 }
		return billD;
	}
		catch(SQLException se)
		   {
			if(se.getErrorCode()==2291)      //2291 means parentkey not found exception in sql
				  throw new BillException("Error Occurred:\nNo bill details fo customer number: "+cnumber);
			  else
				  throw new BillException(se.getMessage());
		   }
	}
	public ArrayList<ConsumersDTO> selectConsumer() throws BillException
	{
		ArrayList<ConsumersDTO> conL=new ArrayList<ConsumersDTO>();
		ConsumersDTO consumer=new ConsumersDTO();
		Connection conn=DbUtil.createConnection();
		
		String sql="select * from consumers";
		try
		{
			Statement pst=conn.createStatement();
			ResultSet rs=pst.executeQuery(sql);
			 while(rs.next())
			 {
				 consumer=new ConsumersDTO();
				 consumer.setConsumerNum(rs.getString(1));
				 consumer.setConsumerName(rs.getString(2));
				 consumer.setAddress(rs.getString(3));
				 conL.add(consumer);
			 }		 
		}
		catch(SQLException se)
		   {
			   throw new BillException(se.getMessage());
		   }
		catch (Exception e)
		{
			throw new BillException("Exception");
		}
		return conL;
	}
}


 














































