package com.cg.exception;

public class BillException extends Exception
{
		public BillException(String msg)
	{
		super(msg);
	}
}
