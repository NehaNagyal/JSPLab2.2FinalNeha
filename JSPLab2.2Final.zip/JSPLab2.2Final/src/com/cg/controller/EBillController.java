package com.cg.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.BillDetailsDTO;
import com.cg.dto.ConsumersDTO;
import com.cg.exception.BillException;
import com.cg.service.EBillServiceImpl;

@WebServlet("/EBillController")
public class EBillController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	BillDetailsDTO bDTO;
	EBillServiceImpl bSer;
	
    public EBillController()
    {
        super();
        
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String action=request.getParameter("action");
	
	switch(action)
	{
	  case "1":
	  {
		  bSer=new EBillServiceImpl();
		  bDTO=new BillDetailsDTO();
		  String cnumber=(request.getParameter("cnum"));
		double lastMeter=Double.parseDouble(request.getParameter("lastmeter"));
		double currMeter=Double.parseDouble(request.getParameter("currmeter"));
		
		double unitC=currMeter-lastMeter;
		double netA=(unitC*1.15+100);
		bDTO.setConsumerNum(cnumber);
		bDTO.setCurrReading(currMeter);
		bDTO.setNetAmount(netA);
		bDTO.setUnitConsumed(unitC);
		bDTO.setBillDate(LocalDate.now());
		try
		{
			int billId=bSer.insertBillDetails(bDTO);
			ConsumersDTO consumer =bSer.selectConsumerDetails(cnumber);
			
			request.setAttribute("bill", bDTO);
			request.setAttribute("consumer", consumer);
				RequestDispatcher rd=request.getRequestDispatcher("Bill_Info.jsp");
				rd.forward(request, response);
			
		}
		catch(BillException be)
		{
			request.setAttribute("Error",be.getMessage());
			RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
			rd.forward(request, response);
		}
		break;
	  }
	  case "2":
	  {
		  bSer=new EBillServiceImpl();
		  ArrayList<ConsumersDTO> conL=new ArrayList<ConsumersDTO>();
		  try
		  {
			conL=bSer.selectConsumer();
			request.setAttribute("ConArray", conL);
			RequestDispatcher rd=request.getRequestDispatcher("Show_consumerList.jsp");
			rd.forward(request, response);
		  } 
		  catch (BillException e) 
		  {
			    request.setAttribute("Error",e.getMessage());
				RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
				rd.forward(request, response);
		  }
		  break;
	  }
	  case "3":
	  {
		  RequestDispatcher rd=request.getRequestDispatcher("Search_Consumer.jsp");
		  rd.forward(request, response);
		  break;
	  }
	  case "4":
	  {
		  bSer=new EBillServiceImpl();
		  String cnumber=(request.getParameter("cnum"));
		  try
		  {
			ConsumersDTO consumer =bSer.selectConsumerDetails(cnumber);
			request.setAttribute("consumer", consumer);
			RequestDispatcher rd=request.getRequestDispatcher("Show_Consumer.jsp");
			rd.forward(request, response);
		  }
		  catch (BillException e) 
		  {
			request.setAttribute("Error",e.getMessage());
			RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
			rd.forward(request, response);
		  }
		  break;
	  }
	  case "5":
	  {
		  bSer=new EBillServiceImpl();
		  ArrayList<BillDetailsDTO> billL=new ArrayList<BillDetailsDTO>();
		  
		  String cnumber=request.getParameter("consumerNo");
		  try
		  {
			  billL=bSer.selectBillDetails(cnumber);
			  request.setAttribute("billL",billL);
			  RequestDispatcher rd=request.getRequestDispatcher("Show_Bills.jsp");
			  rd.forward(request, response);
			  
		  }
		  catch (BillException e) 
		  {
			request.setAttribute("Error",e.getMessage());
			RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
			rd.forward(request, response);
		  }
		  break;  
	  }
	  case "6":
	  {
		  RequestDispatcher rd=request.getRequestDispatcher("User_Info.html");
		  rd.forward(request, response);
		  break; 
	  }
	}
}
}






























