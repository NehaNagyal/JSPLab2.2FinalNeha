package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.BillDetailsDTO;
import com.cg.dto.ConsumersDTO;
import com.cg.exception.BillException;

public interface IEBillServiceI 
{
	public int insertBillDetails(BillDetailsDTO bDTO) throws BillException;
	public ConsumersDTO selectConsumerDetails (String conno) throws BillException;
	public ArrayList<ConsumersDTO> selectConsumer() throws BillException;
	public ArrayList<BillDetailsDTO> selectBillDetails(String cnumber) throws BillException;
	
}
