package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.EBillDAOImpl;
import com.cg.dto.BillDetailsDTO;
import com.cg.dto.ConsumersDTO;
import com.cg.exception.BillException;

public class EBillServiceImpl implements IEBillServiceI
{
	EBillDAOImpl bDAO=new EBillDAOImpl();
   public int insertBillDetails(BillDetailsDTO bDTO) throws BillException
   {
	   int status=0;
	   status=bDAO.insertBillDetails(bDTO);
	   return status;
   }
   
   public ConsumersDTO selectConsumerDetails (String cnumber) throws BillException
   {
	   return bDAO.selectConsumerDetails (cnumber);
   }
   public ArrayList<ConsumersDTO> selectConsumer() throws BillException
   {
	   return bDAO.selectConsumer();
   }

   public ArrayList<BillDetailsDTO> selectBillDetails(String cnumber) throws BillException
   {
	   return bDAO.selectBillDetails(cnumber);
   }
}
