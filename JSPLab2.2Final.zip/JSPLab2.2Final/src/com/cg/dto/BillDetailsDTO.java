package com.cg.dto;

import java.time.LocalDate;

public class BillDetailsDTO
{

	private int billNum;
	private String consumerNum;
	private double currReading;
	private double unitConsumed;
	private double netAmount;
	private LocalDate billDate;
	public BillDetailsDTO() 
	{
		super();
	}
	public BillDetailsDTO(int billNum, String consumerNum, double currReading,
			double unitConsumed, double netAmount, LocalDate billDate) 
	{
		super();
		this.billNum = billNum;
		this.consumerNum = consumerNum;
		this.currReading = currReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.billDate = billDate;
	}
	public int getBillNum() {
		return billNum;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	public String getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(String consumerNum) {
		this.consumerNum = consumerNum;
	}
	public double getCurrReading() {
		return currReading;
	}
	public void setCurrReading(double currReading) {
		this.currReading = currReading;
	}
	public double getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(double unitConsumed)
	{
		this.unitConsumed = unitConsumed;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public LocalDate getBillDate() {
		return billDate;
	}
	public void setBillDate(LocalDate billDate) {
		this.billDate = billDate;
	}
	@Override
	public String toString() {
		return "BillDetailsDTO [billNum=" + billNum + ", consumerNum="
				+ consumerNum + ", currReading=" + currReading
				+ ", unitConsumed=" + unitConsumed + ", netAmount=" + netAmount
				+ ", billDate=" + billDate + "]";
	}
	
	
}
